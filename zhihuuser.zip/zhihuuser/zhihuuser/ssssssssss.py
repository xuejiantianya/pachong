import os

local_filename = "/root/path/treee"
filename = os.path.split(local_filename)

print(filename)